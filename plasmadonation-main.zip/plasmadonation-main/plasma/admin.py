from django.contrib import admin

from .models import plasmaregister

admin.site.register(plasmaregister)
