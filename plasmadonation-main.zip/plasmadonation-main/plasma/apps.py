from django.apps import AppConfig


class PlasmaConfig(AppConfig):
    name = 'plasma'
